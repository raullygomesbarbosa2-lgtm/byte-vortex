# Byte Vortex — primeira versão

Esta entrega é o **projeto-fonte** do app, não um APK já compilado/assinado. A imagem de execução atual não tem JDK, Android SDK nem Gradle; por isso não é possível produzir um APK válido neste ambiente.

## Conteúdo
- `web/`: versão web/PWA, com busca, filtros, projetos de emulação e links para os sites oficiais. Para instalar como PWA, hospede a pasta em um endereço HTTPS e abra no Chrome do Android; use o menu do navegador > **Instalar app** / **Adicionar à tela inicial**.
- `android/`: projeto Android Studio que carrega a mesma interface incluída em `app/src/main/assets/`. Não requer chaves privadas nem backend.

## Gerar APK no Android Studio
1. Instale o Android Studio em um computador e os componentes Android SDK recomendados.
2. Abra a pasta `android/` como projeto (não abra apenas a subpasta `app`). Aguarde a sincronização do Gradle.
3. Use **Build > Build Bundle(s) / APK(s) > Build APK(s)**. O APK de teste ficará em `android/app/build/outputs/apk/debug/app-debug.apk`.
4. Para distribuir publicamente, gere uma versão assinada em **Build > Generate Signed Bundle / APK** e proteja o keystore e a senha. Não compartilhe o APK de debug como lançamento.

## Escopo e segurança
O app é uma vitrine/atalho para os sites oficiais dos projetos. Não contém jogos, ROMs, BIOS, emuladores baixados nem pagamentos. Confirme a procedência, licença e compatibilidade em cada site antes de instalar software. A interface mostra uma confirmação antes de sair para um site externo.
